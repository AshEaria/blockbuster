/**
 * 
 */
package aplicacion;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import catalogo.Articulo;
import catalogo.Catalogo;
import catalogo.Categoria;
import catalogo.Ejemplar;
import catalogo.EstadoEjemplar;
import catalogo.ListaEjemplares;
import catalogo.Musica;
import catalogo.Pelicula;
import catalogo.Serie;
import socios.Alquiler;
import socios.EstadoSocio;
import socios.ListaAlquileres;
import socios.ListaContratos;
import socios.ListaSocios;
import socios.Socio;
import socios.Tarifa;
import socios.TarifaMusica;
import socios.TarifaPM;
import socios.TarifaPS;
import socios.TarifaPelicula;
import socios.TarifaPremium;
import socios.TarifaSM;
import socios.TarifaSerie;

/**
 * Esta clase representa la aplicacion en si. Contiene todos los listados y
 * gestiona el login. Esta clase se terminara de implementar mas adelante por
 * formar parte de la interfaz de usuario.
 * 
 * @author Jaime Monedero y Elena Lechuga
 */
public class Aplicacion {
	private static Aplicacion INSTANCE = null;
	
	/* PATRON SINGLETON */
	
	public static Aplicacion getInstance() {
		if (INSTANCE == null)
			INSTANCE = new Aplicacion();
		return INSTANCE;
	}

	/* MAIN */

	/**
	 * Punto de entrada a la aplicacion. Por el momento es un main de prueba de funcionalidad. En su version final gestionara la inicializacion de bases de datos y el login.
	 * 
	 */
	public static void main(String[] args) {
		
		Aplicacion aplicacion = Aplicacion.getInstance();
		
		System.out.println("Pruebas de conjunto de la aplicacion: ");
		System.out.println();
		System.out.println("00. Recuperar la base de datos de los ficheros. ");
		System.out.println("01. Crear un nuevo articulo. ");
		System.out.println("02. Crear un ejemplar de ese articulo. ");
		System.out.println("03. Anadir el articulo a una categoria. ");
		System.out.println("04. Crear un nuevo socio. ");
		System.out.println("05. Contratar una tarifa para el socio. ");
		System.out.println("06. Hacer que este socio alquile el ejemplar. ");
		System.out.println("07. Devolver el ejemplar. ");
		System.out.println("08. Eliminar el socio, y con el la tarifa. ");
		System.out.println("09. Eliminar el ejemplar. ");
		System.out.println("10. Eliminar el articulo. ");
		System.out.println("11. Guardar la base de datos en archivo. ");
		System.out.println();
		System.out.println();
		System.out.println("Resultados:");
		System.out.println();
		
		boolean checker = false; 
		
		checker = aplicacion.inicializaListas();
		
		if (checker == false) System.out.println("00: ERROR al inicializar la base de datos. ");
		else System.out.println("00: OK al inicializar la base de datos. ");
		
		
		
		Catalogo catalogo = Catalogo.getInstance();
		
		Articulo art = catalogo.encuentra(catalogo.crearSerie("Fringe", 3, 1));
		
		if (art == null) System.out.println("01: ERROR al crear un nuevo articulo. ");
		else System.out.println("01: OK al crear un nuevo articulo. ");
		
		
		
		ListaEjemplares listaEjemplares = ListaEjemplares.getInstance();
		
		Ejemplar ejem = listaEjemplares.encuentra(listaEjemplares.anadirEjemplar(art, false, EstadoEjemplar.DISPONIBLE));
		
		if (ejem == null) System.out.println("02: ERROR al crear un nuevo ejemplar. ");
		else System.out.println("02: OK al crear un nuevo ejemplar. ");
		
		
		
		checker = art.anadirCategoria("Ciencia ficcion");
		
		if (checker == false) System.out.println("03: ERROR al anadir articulo a una categoria. ");
		else System.out.println("03: OK al anadir articulo a una categoria. ");
		
		
		
		ListaSocios listaSocios = ListaSocios.getInstance();
		
		Socio soc = listaSocios.encuentra(listaSocios.crearSocio("54169551H", "Jose de la Vera", "684523169", "jose@vera.es", "Paseo del Pardo 3"));
		
		if (soc == null) System.out.println("04: ERROR al crear un nuevo socio. ");
		else System.out.println("04: OK al crear un nuevo socio. ");
		
		
		
		ListaContratos listaContratos = ListaContratos.getInstance();
		
		Tarifa tar = listaContratos.encuentra(listaContratos.crearTarifa(soc, "TS", true));
		
		if (tar == null) System.out.println("05: ERROR al contratar una nueva tarifa. ");
		else System.out.println("05: OK al contratar una nueva tarifa. ");
		
		
		
		ListaAlquileres listaAlquileres = ListaAlquileres.getInstance();
		
		Alquiler alq = listaAlquileres.encuentra(listaAlquileres.crearAlquiler(ejem, soc));
		
		if (alq == null) System.out.println("06: ERROR al efectuar un alquiler. ");
		else System.out.println("06: OK al efectuar un alquiler. ");
		
		
		
		checker = listaAlquileres.terminarAlquiler(alq, false);
		
		checker = (checker && !(listaAlquileres.getAlquileres().contains(alq)));
		checker = (checker && !(soc.getAlquileres().contains(alq)));
		checker = (checker && soc.getEstadoSocio() == EstadoSocio.SIN_ALQUILERES);
		checker = (checker && ejem.getEstadoEjem() == EstadoEjemplar.DISPONIBLE);
		
		if (checker == false) System.out.println("07: ERROR al devolver un articulo. ");
		else System.out.println("07: OK al devolver un articulo. ");
		
		
		
		checker = listaSocios.darBajaSocio(soc);
		
		checker = (checker && !(listaSocios.getSocios().contains(soc)));
		checker = (checker && !(listaContratos.getContratos().contains(tar)));
		
		if (checker == false) System.out.println("08: ERROR al dar de baja a un socio. ");
		else System.out.println("08: OK al dar de baja a un socio. ");
		
		
		
		checker = listaEjemplares.eliminarEjemplar(ejem);
		
		checker = (checker && !(listaEjemplares.getEjemplares().contains(ejem)));
		checker = (checker && !(art.getEjemplares().contains(ejem)));
		
		if (checker == false) System.out.println("09: ERROR al eliminar un ejemplar. ");
		else System.out.println("09: OK al eliminar un ejemplar. ");
		
		
		
		checker = catalogo.eliminarArticulo(art);
		
		checker = (checker && !(catalogo.getArticulos().contains(art)));
		checker = (checker && !(catalogo.encuentra("Ciencia ficcion", "Serie").getArticulos().contains(art)));
		
		if (checker == false) System.out.println("10: ERROR al eliminar un articulo. ");
		else System.out.println("10: OK al eliminar un articulo. ");
		
		
		
		checker = aplicacion.cierraAplicacion();
		
		if (checker == false) System.out.println("11: ERROR al guardar la base de datos en archivo. ");
		else System.out.println("11: OK al guardar la base de datos en archivo. ");
		
		System.out.println();
		System.out.println();
		
		System.out.println("Fin de las pruebas");
		
	}

	/* METODOS COMPLEJOS */

	/**
	 * Inicializa todas las bases de datos a partir de ficheros, llamando a los
	 * constructores de cada una.
	 * 
	 * @return true si se inicializan correctamente, false si hay algun error.
	 */
	public boolean inicializaListas() {
		Catalogo.getInstance();
		ListaSocios.getInstance();
		ListaAlquileres.getInstance();
		ListaContratos.getInstance();

		return true;
	}

	/**
	 * Abre la aplicacion y gestiona el login.
	 * 
	 * @return true si se ha abierto correctamente, false en caso contrario.
	 */
	public boolean abreAplicacion() {
		//////////////////////////////////////////////////////////////////
		return true;
	}

	/**
	 * Guarda todos los datos en ficheros y cierra la aplicacion.
	 * 
	 * @return true si el guardado se hace correctamente, false en caso
	 *         contrario.
	 */
	public boolean cierraAplicacion() {

		boolean error = true;

		try {
			guardaCatalogo();
			guardaListaAlquileres();
			guardaListaContratos();
			guardaListaSocios();
		}
		catch (Exception ex) {
			error = false;
		}

		return error;
	}

	/**
	 * Guarda el catalogo en el archivo que le corresponde. 
	 * 
	 * @return true si se ha ejecutado correctamente. 
	 * @throws IOException
	 */
	public boolean guardaCatalogo() throws IOException {
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(
				"articulos.txt"))) {

			bw.write(Catalogo.getNumArticulos() + ","
					+ Catalogo.getNumCategorias() + "," + Articulo.getLastId()
					+ "," + Ejemplar.getLastId());
			bw.newLine();
			bw.write(Pelicula.getPrecio() + "," + Serie.getPrecio() + ","
					+ Musica.getPrecio());
			bw.newLine();
			for (Articulo a : Catalogo.getInstance().getArticulos()) {
				bw.write(a.toString());
				for (Ejemplar e : a.getEjemplares()) {
					bw.write(e.toString());
					bw.newLine();
				}
				for (Categoria c : a.getCategorias()) {
					bw.write(c.toString());
					bw.newLine();
				}
			}
			bw.close();
		}

		return true;
	}

	/**
	 * Guarda la lista de socios en el archivo que le corresponde. 
	 * 
	 * @return true si se ha ejecutado correctamente. 
	 * @throws IOException
	 * @throws FileNotFoundException
	 * @throws UnsupportedEncodingException
	 */
	public boolean guardaListaSocios() throws UnsupportedEncodingException,
			FileNotFoundException, IOException {

		try (BufferedWriter bw = new BufferedWriter(
				new FileWriter("socios.txt"))) {

			bw.write(ListaSocios.getNumSocios() + "," + Socio.getLastId());
			bw.newLine();
			for (Socio s : ListaSocios.getInstance().getSocios()) {
				bw.write(s.toString());
				bw.newLine();
			}
			bw.close();
		}

		return true;
	}

	/**
	 * Guarda la lista de alquileres en el archivo que le corresponde. 
	 * 
	 * @return true si se ha ejecutado correctamente. 
	 * @throws IOException 
	 */
	public boolean guardaListaAlquileres() throws IOException {
		try (BufferedWriter bw = new BufferedWriter(
				new FileWriter("alquileres.txt"))) {

			bw.write(ListaAlquileres.getNumAlquileres() + "," + Alquiler.getLastId());
			bw.newLine();
			for (Alquiler s : ListaAlquileres.getInstance().getAlquileres()) {
				bw.write(s.toString());
				bw.newLine();
			}
			bw.close();
		}

		return true;
	}

	/**
	 * Guarda la lista de contratos en el archivo que le corresponde. 
	 * 
	 * @return true si se ha ejecutado correctamente. 
	 */
	public boolean guardaListaContratos() throws IOException {
		
		try (BufferedWriter bw = new BufferedWriter(
				new FileWriter("contratos.txt"))) {

			bw.write(ListaContratos.getNumTarifas() + ","+Tarifa.getLastId()+","+Tarifa.getExtraPlus());
			bw.newLine();
			bw.write(TarifaPelicula.getPrecio()+","+TarifaSerie.getPrecio()+","+TarifaMusica.getPrecio()+","
					+TarifaPS.getPrecio()+","+TarifaPM.getPrecio()+","+TarifaSM.getPrecio()+","+TarifaPremium.getPrecio());
			bw.newLine();
			for (Tarifa t : ListaContratos.getInstance().getContratos()) {
				bw.write(t.toString());
				bw.newLine();
			}
			bw.close();
		}

		return true;
	}

}
