/**
 * 
 */
package aplicacion;

/**
 * Esta clase se implementara mas adelante por formar parte de la interfaz de usuario. 
 * 
 * @author Elena Lechuga y Jaime Monedero
 */
public class Gerente extends Sesion{

	private String contrasena;
	
	/* CONSTRUCTOR */
	
	public Gerente(String contrasena) {
		this.contrasena= contrasena;
	}
	
	
	/*METODOS COMPLEJOS*/
	
	/**
	 * Metodo encargado de gestionar el login de la sesion de gerente. 
	 * @return true si el usuario ha podido hacer login, false en caso contrario.
	 */
	public boolean login(){
		////////////////////////////////////////
		return false;
	}

	
	
	/*GETTERS*/

	/**
	 * Metodo de acceso a la contrasena de la sesion gerente. 
	 * 
	 * @return Contrasena de acceso a la sesion de gerente. 
	 */
	public String getContrasena() {
		return contrasena;
	}

	
	
	/*SETTERS*/
	
	/**
	 * Metodo para cambiar la contrasena de la sesion gerente. 
	 * 
	 * @param contrasena Nueva contrasena. 
	 */
	public void setContrasena(String contrasena) {
		this.contrasena = contrasena;
	}	
	
}
