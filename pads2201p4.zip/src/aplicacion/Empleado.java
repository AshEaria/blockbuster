/**
 * 
 */
package aplicacion;

/**
 * Esta clase se implementara mas adelante por formar parte de la interfaz de usuario. 
 * 
 * @author Elena Lechuga y Jaime Monedero
 */
public class Empleado extends Sesion {

	/**
	 * Metodo encargado de gestionar el inicio de una sesion de empleado. 
	 * 
	 * @return true si el usuario ha podido hacer login, false en caso contrario.
	 */
	public boolean login() {
		///////////////////////////////////////////////
		return false;
	}

}
