/**
 * 
 */
package aplicacion;

/**
 * Esta clase se implementara mas adelante por formar parte de la interfaz de usuario. 
 * 
 * @author Jaime Monedero y Elena Lechuga
 */

public abstract class Sesion {

	/**
	 * Metodo encargado de gestionar el inicio de sesion. 
	 * 
	 * @return true si el usuario ha podido hacer login, false en caso contrario.
	 */
	public abstract boolean login();
	
}
